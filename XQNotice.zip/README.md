﻿# XQNotice  
XQNotice V1.1  
类别：Chrome插件  
作用：弹出通知提醒  

版本V1.1  
修正多条调仓操作只显示一条的问题。  


